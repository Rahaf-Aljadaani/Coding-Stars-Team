import UIKit

var name: String = "Rakan alqahtani"
