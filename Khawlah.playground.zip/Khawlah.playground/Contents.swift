import Foundation

var name :String = "Khawlah Alrashed"

